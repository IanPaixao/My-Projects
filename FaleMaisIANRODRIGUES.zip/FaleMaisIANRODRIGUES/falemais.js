/*
CÓDIGO DE IAN RODIGUES DOS REIS PAIXÃO EMAIL: IANG.MASTERT100@GMAIL.COM
*/
function priceA(){
const tarifa = 1.90;
const fale = 30;
var timedif;
var faletempo;
var perc;
var faletotal;
var total;
var input = parseInt(document.getElementById("A").value)
				timedif = input - fale;
        if(timedif > 0){
        faletempo = timedif * tarifa ;
        perc = (10 / 100) * faletempo;
        faletotal = faletempo + perc;
        }
        else {
        faletotal = 0;
        }
        total = input * tarifa;
        document.getElementById("CFMA").innerHTML = faletotal;
       document.getElementById("SFMA").innerHTML = total;
    
}
function priceB(){
const tarifa = 1.70;
const fale = 60;
var timedif;
var faletempo;
var perc;
var faletotal;
var total;
var input = parseInt(document.getElementById("B").value)
				timedif = input - fale;
        if(timedif > 0){
        faletempo = timedif * tarifa ;
        perc = (10 / 100) * faletempo;
        faletotal = faletempo + perc;
        }
        else {
        faletotal = 0;
        }
        total = input * tarifa;
        document.getElementById("CFMB").innerHTML = faletotal;
       document.getElementById("SFMB").innerHTML = total;
    
}
function priceC(){
const tarifa = 0.90;
const fale = 120;
var timedif;
var faletempo;
var perc;
var faletotal;
var total;
var input = parseInt(document.getElementById("C").value)
				timedif = input - fale;
        if(timedif > 0){
        faletempo = timedif * tarifa ;
        perc = (10 / 100) * faletempo;
        faletotal = faletempo + perc;
        }
        else {
        faletotal = 0;
        }
        total = input * tarifa;
        document.getElementById("CFMC").innerHTML = faletotal;
       document.getElementById("SFMC").innerHTML = total;
    
}
function priceD(){
const tarifa = 2.90;
const fale = 30;
var timedif;
var faletempo;
var perc;
var faletotal;
var total;
var input = parseInt(document.getElementById("D").value)
				timedif = input - fale;
        if(timedif > 0){
        faletempo = timedif * tarifa ;
        perc = (10 / 100) * faletempo;
        faletotal = faletempo + perc;
        }
        else {
        faletotal = 0;
        }
        total = input * tarifa;
        document.getElementById("CFMD").innerHTML = faletotal;
       document.getElementById("SFMD").innerHTML = total;
    
}
function priceE(){
const tarifa = 2.70;
const fale = 30;
var timedif;
var faletempo;
var perc;
var faletotal;
var total;
var input = parseInt(document.getElementById("E").value)
				timedif = input - fale;
        if(timedif > 0){
        faletempo = timedif * tarifa ;
        perc = (10 / 100) * faletempo;
        faletotal = faletempo + perc;
        }
        else {
        faletotal = 0;
        }
        total = input * tarifa;
        document.getElementById("CFME").innerHTML = faletotal;
       document.getElementById("SFME").innerHTML = total;
    
}
function priceF(){
const tarifa = 1.90;
const fale = 30;
var timedif;
var faletempo;
var perc;
var faletotal;
var total;
var input = parseInt(document.getElementById("F").value)
				timedif = input - fale;
        if(timedif > 0){
        faletempo = timedif * tarifa ;
        perc = (10 / 100) * faletempo;
        faletotal = faletempo + perc;
        }
        else {
        faletotal = 0;
        }
        total = input * tarifa;
        document.getElementById("CFMF").innerHTML = faletotal;
       document.getElementById("SFMF").innerHTML = total;
    
}
function priceG(){
const tarifa = 2.90;
const fale = 60;
var timedif;
var faletempo;
var perc;
var faletotal;
var total;
var input = parseInt(document.getElementById("G").value)
				timedif = input - fale;
        if(timedif > 0){
        faletempo = timedif * tarifa ;
        perc = (10 / 100) * faletempo;
        faletotal = faletempo + perc;
        }
        else {
        faletotal = 0;
        }
        total = input * tarifa;
        document.getElementById("CFMG").innerHTML = faletotal;
       document.getElementById("SFMG").innerHTML = total;
    
}
function priceH(){
const tarifa = 2.70;
const fale = 60;
var timedif;
var faletempo;
var perc;
var faletotal;
var total;
var input = parseInt(document.getElementById("H").value)
				timedif = input - fale;
        if(timedif > 0){
        faletempo = timedif * tarifa ;
        perc = (10 / 100) * faletempo;
        faletotal = faletempo + perc;
        }
        else {
        faletotal = 0;
        }
        total = input * tarifa;
        document.getElementById("CFMH").innerHTML = faletotal;
       document.getElementById("SFMH").innerHTML = total;
    
}
function priceI(){
const tarifa = 1.90;
const fale = 60;
var timedif;
var faletempo;
var perc;
var faletotal;
var total;
var input = parseInt(document.getElementById("I").value)
				timedif = input - fale;
        if(timedif > 0){
        faletempo = timedif * tarifa ;
        perc = (10 / 100) * faletempo;
        faletotal = faletempo + perc;
        }
        else {
        faletotal = 0;
        }
        total = input * tarifa;
        document.getElementById("CFMI").innerHTML = faletotal;
       document.getElementById("SFMI").innerHTML = total;
    
}
function priceJ(){
const tarifa = 2.90;
const fale = 120;
var timedif;
var faletempo;
var perc;
var faletotal;
var total;
var input = parseInt(document.getElementById("J").value)
				timedif = input - fale;
        if(timedif > 0){
        faletempo = timedif * tarifa ;
        perc = (10 / 100) * faletempo;
        faletotal = faletempo + perc;
        }
        else {
        faletotal = 0;
        }
        total = input * tarifa;
        document.getElementById("CFMJ").innerHTML = faletotal;
       document.getElementById("SFMJ").innerHTML = total;
    
}
function priceK(){
const tarifa = 2.70;
const fale = 120;
var timedif;
var faletempo;
var perc;
var faletotal;
var total;
var input = parseInt(document.getElementById("K").value)
				timedif = input - fale;
        if(timedif > 0){
        faletempo = timedif * tarifa ;
        perc = (10 / 100) * faletempo;
        faletotal = faletempo + perc;
        }
        else {
        faletotal = 0;
        }
        total = input * tarifa;
        document.getElementById("CFMK").innerHTML = faletotal;
       document.getElementById("SFMK").innerHTML = total;
    
}
function priceL(){
const tarifa = 1.90;
const fale = 120;
var timedif;
var faletempo;
var perc;
var faletotal;
var total;
var input = parseInt(document.getElementById("L").value)
				timedif = input - fale;
        if(timedif > 0){
        faletempo = timedif * tarifa ;
        perc = (10 / 100) * faletempo;
        faletotal = faletempo + perc;
        }
        else {
        faletotal = 0;
        }
        total = input * tarifa;
        document.getElementById("CFML").innerHTML = faletotal;
       document.getElementById("SFML").innerHTML = total;
    
}