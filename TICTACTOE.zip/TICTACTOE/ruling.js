/*Arquivo pertencente a Ian Rodrigues dos Reis Paixão  ian.paxiao@sga.pucminas.br*/ 
/* Arquivo javascrpit responsavel pela jogabilidade */
const squares = []; // vetor que tera como elementos os quadrados do tabuleiro bem como seus respectivos valores.
const EMPTY = ''; // variavel que guarda um espaço em branco que é utilizada na preparação do tabuleiro.
let score; // variavel que guarda os pontos dos jogadores.
let moves; // variavel que contara o numero de movimentos realizados durante o jogo.
let turn; // variavel que guardara qual jogador esta ativo, inicialmente.
var initialTime; // variavel que guarda o tempo de quando o jogo foi inciado.
var timeX; // variavel para contabilização do tempo do jogador x.
var timeO; // variavel para contabilização do tempo do jogador O.
var movesX;// variavel para contabilização das jogadas do jogador X.
var movesO;// variavel para contabilização das jogadas do jogador O.
const wins = [35,280,365,420,730,1365,1460,2240];// vetor que guarda 8 somas de valores que representam condições para a vitoria no jogo.

/*
 * Metodo que tem como função preparar o tabuleiro dando conticoes para 
 * que o jogo de fato ocorra.
 */
function startNewGame() {
  initialTime = Date.now();
  turn = 'X';
  score = { X: 0, O: 0 };
  moves = 0;
  for (let i = 0; i < squares.length; i += 1) {
    squares[i].firstChild.nodeValue = EMPTY;
  }// fim for
}// fim new game

/*
 * Metodo que é resposavel pela verificacao da pontual de um dado jogador,  
 * ao realizar uma comparação com os possiveis valores que levam a vitoria.
 * Para vencer a tabela é marcada com multiplos de 5 , uma vez marcado um quadrado
 * o valor que o ultimo guarda é acrescido a variavel score.
 * Verificando se valor guardado em score  for igual a algum valor do vetor
 * wins (que guarda os possiveis valores de vitoria ) a vitoria e dada ao jogador.
 */
window.onload = function () {
  let marker = 5;
  for (let i = 0; i < 3; i += 1) {
    for (let j = 0; j < 3; j += 1) {
      const cell = document.getElementById("cell" + i + j);
      cell.marker= marker;
      cell.onclick = markit;
      cell.appendChild(document.createTextNode(''));
      squares.push(cell);
      marker += marker;
    }
  }
  startNewGame();
};


/*
 * Metodo que é resposavel pela verificacao da pontual de um dado jogador,  
 * ao realizar uma comparação com os possiveis valores que levam a vitoria.
 * Para vencer a tabela é marcada com multiplos de 5 , uma vez marcado um quadrado
 * o valor que o ultimo guarda é acrescido a variavel score.
 * Verificando se valor guardado em score  for igual a algum valor do vetor
 * wins (que guarda os possiveis valores de vitoria ) a vitoria e dada ao jogador.
 */
function winner(score) {
  for (let i = 0; i < wins.length; i += 1) {
    if ( score === wins[i]) {
      return true;
    }// fim if
  }// fim for
  return false;
}// fim winner

/*
 * Metodo que é resposavel pela jogabilidade, uma vez identificado o jogador e selecionado o quadrado,
 * o ultima sera marcado com um 'X' Ou 'O' os respectivos contadores de turnos serao acrescidos em 1 unidade
 * e finalmente serao testadas as possibilidades para a vitoria ou empate.
 * O empate é declarado quando o numero de movimentos realizados atingir o numero 8, sendo este o numero
 * o valor encontrado por mim apos varios testes de jogadas.
 */
function markit() {
  if(turn == 'X'){
     timeX = Date.now();
     movesX+=1;
  }// fim else X   
  else{
     timeO = Date.now();
     movesO+=1;
  }// fim else O   
  if (this.firstChild.nodeValue !== EMPTY) {
    return;
  }// fim if emptty
  this.firstChild.nodeValue = turn;
  moves += 1;
  score[turn] += this.marker;
  if (winner(score[turn])) {
    //document.getElementById('turn').style.background = "red";
    document.getElementById('turn').textContent = 'Jogador ' + turn + '  venceu !';
    var timeDifference = Date.now() - initialTime;
    var totaltime = convertTime(timeDifference);
    timeDifference = Date.now() - timeX;
    timeX = convertTime(timeDifference);
    timeDifference = Date.now() - timeO;
    timeO = convertTime(timeDifference);
    startNewGame();
  } else if (moves === 8) {
    document.getElementById('turn').textContent = 'Empate !';
    var timeDifference = Date.now() - initialTime;
    var totaltime = convertTime(timeDifference);
    timeDifference = Date.now() - timeX;
    var xtime = convertTime(timeDifference);
    timeDifference = Date.now() - timeO;
    var otime = convertTime(timeDifference);
    startNewGame();
  } else {
    turn = turn === 'X' ? 'O' : 'X';
    document.getElementById('turn').textContent = 'Vez de: ' + turn;
  }// fim else
}// fim mark it

/*
* Metodo de conversao do tempo recebido pela função Date.now() 
* para minutos e segundos.
*/ 
function convertTime(miliseconds) {
  var totalSeconds = Math.floor(miliseconds/1000);
  var minutes = Math.floor(totalSeconds/60);
  var seconds = totalSeconds - minutes * 60;
  return minutes + ' minutes :' + seconds + ' seconds';
}// fim convert time